<script type="text/javascript" src="<?= base_url('assets'); ?>/js/jquery.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets'); ?>/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $('#sidebarCollapse').on('click', function() {
            $('#sidebar').toggleClass('active');
        });
    });
</script>
</body>

</html>