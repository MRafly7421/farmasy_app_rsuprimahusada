<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $dbName = "db_farmasy_app_primhus";
    $koneksi = mysqli_connect($host,$user,$pass,$dbName); 
?>